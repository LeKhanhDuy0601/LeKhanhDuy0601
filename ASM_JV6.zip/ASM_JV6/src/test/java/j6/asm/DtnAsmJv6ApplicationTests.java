package j6.asm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtnAsmJv6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
